package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdbProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdbProjectApplication.class, args);
	}

}
