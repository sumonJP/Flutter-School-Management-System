package com.example.school_management;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
