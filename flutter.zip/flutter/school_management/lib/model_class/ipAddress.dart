class Ip{
  String ipAddress = "http://192.168.43.44:8080";

}